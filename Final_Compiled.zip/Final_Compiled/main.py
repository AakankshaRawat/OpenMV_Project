# Runs ON the OpenMV RT1062 board

import sensor, time, ml, uos, gc, utime
from led_control import control_led, all_off
from openmv_wifi_sender import connect_wifi, send_alert

# ---- Camera setup ----
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((240, 240))
sensor.skip_frames(time=2000)

# ---- Load object detection model (what fruit?) ----
try:
    obj_net = ml.Model("object_det.tflite",
                       load_to_fb=uos.stat('object_det.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    raise Exception('Failed to load object_det.tflite: ' + str(e))

try:
    obj_labels = [line.rstrip('\n') for line in open("object_det.txt")]
except Exception as e:
    raise Exception('Failed to load object_det.txt: ' + str(e))

# ---- Load freshness model (fresh/rotten/unripe?) ----
try:
    fresh_net = ml.Model("freshness.tflite",
                         load_to_fb=uos.stat('freshness.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    raise Exception('Failed to load freshness.tflite: ' + str(e))

try:
    fresh_labels = [line.rstrip('\n') for line in open("freshness.txt")]
except Exception as e:
    raise Exception('Failed to load freshness.txt: ' + str(e))

# ---- Connect to WiFi ----
connect_wifi()

# ---- Cooldown settings ----
LAST_ALERT_TIME  = 0
LAST_DETECTION_TIME  = 0
ALERT_COOLDOWN   = 5    # seconds between alerts
DETECTION_INTERVAL   = 10
MIN_CONFIDENCE   = 0.70  # minimum confidence to act on

clock = time.clock()
all_off()

print("System ready - scanning for fruit...")

# ---- Main loop ----
while True:
    clock.tick()
    img = sensor.snapshot()
    now = utime.time()

    # Only run detection every 15 seconds
    if LAST_DETECTION_TIME != 0 and now - LAST_DETECTION_TIME < DETECTION_INTERVAL:
        print("Waiting for next detection...")
        print("FPS: %.1f" % clock.fps())
        continue

    # LAST_DETECTION_TIME = now

    # --- Step 1: Object detection — what fruit is it? ---
    obj_preds = list(zip(obj_labels,
                         obj_net.predict([img])[0].flatten().tolist()))
    obj_preds.sort(key=lambda x: x[1], reverse=True)
    top_obj_label, top_obj_conf = obj_preds[0]

    print("\n--- Object Detection ---")
    for label, conf in obj_preds:
        print("  %s = %.2f" % (label, conf))

    # --- Step 2: Freshness classification — fresh/rotten/unripe? ---
    fresh_preds = list(zip(fresh_labels,
                           fresh_net.predict([img])[0].flatten().tolist()))
    fresh_preds.sort(key=lambda x: x[1], reverse=True)
    top_fresh_label, top_fresh_conf = fresh_preds[0]

    print("--- Freshness Classification ---")
    for label, conf in fresh_preds:
        print("  %s = %.2f" % (label, conf))

    # --- Step 3: Only act if confidence is high enough ---
    if top_obj_conf >= MIN_CONFIDENCE and top_fresh_conf >= MIN_CONFIDENCE:
        LAST_DETECTION_TIME = now
        now = utime.time()

        # No fruit detected — send one notification and turn off LEDs
        if top_obj_label == "No_Fruit_Detected":
            if now - LAST_ALERT_TIME > ALERT_COOLDOWN:
                print("-> No fruit detected")
                all_off()
                # Notification 1: no fruit
                send_alert("No_Fruit_Detected", top_obj_conf)
                LAST_ALERT_TIME = now

        else:
            # Fruit detected
            if now - LAST_ALERT_TIME > ALERT_COOLDOWN:
                print("-> Fruit: %s (%.0f%%)" % (top_obj_label, top_obj_conf * 100))
                print("-> Freshness: %s (%.0f%%)" % (top_fresh_label, top_fresh_conf * 100))

                # LED control based on freshness
                control_led(top_fresh_label)

                # Notification 1: what fruit is detected
                send_alert("Fruit_Detected:" + top_obj_label, top_obj_conf)

                # Small gap between the two notifications
                utime.sleep_ms(2000)

                # Notification 2: freshness result
                send_alert(top_fresh_label, top_fresh_conf)

                LAST_ALERT_TIME = now
    else:
        print("-> Low confidence — continuing detection immediately (obj: %.0f%%, fresh: %.0f%%)"
              % (top_obj_conf * 100, top_fresh_conf * 100))
        all_off()
        LAST_DETECTION_TIME = 0

    print("FPS: %.1f" % clock.fps())
