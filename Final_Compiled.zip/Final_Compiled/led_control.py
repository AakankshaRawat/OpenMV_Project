from machine import LED

led_red   = LED("LED_RED")
led_green = LED("LED_GREEN")
led_blue  = LED("LED_BLUE")

def all_off():
    led_red.off()
    led_green.off()
    led_blue.off()

def control_led(label):

    all_off()

    if "Fresh" in label:
        led_green.on()
        print("GREEN LED ON")

    elif "Unripe" in label:
        led_blue.on()
        print("BLUE LED ON")

    elif "Rotten" in label:
        led_red.on()
        print("RED LED ON")

    else:
        print("No LED condition matched")